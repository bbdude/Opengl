#include "StdAfx.h"
#include "BasicShape.h"


BasicShape::BasicShape(void)
{
}


BasicShape::~BasicShape(void)
{
}
