#include "StdAfx.h"
#include "Enemy.h"


Enemy::Enemy(void)
{
}


Enemy::~Enemy(void)
{
}
